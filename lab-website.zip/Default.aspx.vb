﻿
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Page_Init(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Init
        Me.labeltest.Text = System.DateTime.Now.ToString()
    End Sub
End Class
